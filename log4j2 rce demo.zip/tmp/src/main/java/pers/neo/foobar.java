package pers.neo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class foobar extends HttpServlet{
    private String message;
    private static Logger logger_ =LogManager.getLogger();

    public void init() throws ServletException
    {
        // 执行必需的初始化
        message = "Hello World my servlet";
//        System.setProperty("log4j.configurationFile", "log4j2.properties");
    }

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
            throws ServletException, IOException
    {
        // 设置响应内容类型
        response.setContentType("text/html");

        // 实际的逻辑是在这里
        PrintWriter out = response.getWriter();

//        out.println("<h1>" + message + "</h1>");
        out.println("<h1>" + "hello neo" + "</h1>");
//        out.println("<h1>" + request.getParameter("a") + "</h1>");

        out.println("<br>param a\t"+request.getParameter("a"));
        out.println("<br>param uri\t"+request.getRequestURI());
//        out.println("<br>param name\t"+ String.join("", request.getParameterNames());
        out.println("<br>cookie\t"+request.getCookies());
        out.println("<br>ua\t"+request.getHeader("user-agent"));
        out.println("<br>origin\t"+request.getHeader("origin"));


        logger_.error("param a\t"+request.getParameter("a"));
        logger_.error("param uri\t"+request.getRequestURI());
//        logger_.error("param name\t"+String.join("", request.getParameterNames().nextElement().toString()));
        logger_.error("cookie\t"+request.getCookies().toString());
        logger_.error("ua\t"+request.getHeader("user-agent"));
        logger_.error("origin\t"+request.getHeader("origin"));
    }

    public void destroy()
    {
        // 什么也不做
    }

}
